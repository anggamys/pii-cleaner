"""
clean_pii.py — Main CLI untuk membersihkan PII dari file chat.
Mendeteksi & menghapus nomor telepon dan email.

Cara pakai:
  python3 clean_pii.py                  -> preview 1 file test
  python3 clean_pii.py scan             -> scan semua file
  python3 clean_pii.py run              -> proses semua file -> result/
  python3 clean_pii.py apply            -> apply 1 file (in-place)
  python3 clean_pii.py apply-all --yes  -> apply semua file (in-place)
"""

import os
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from find_emails import detect as detect_email
from find_emails import replace as replace_email
from find_phones import detect as detect_phone
from find_phones import replace as replace_phone
from find_rekening import detect as detect_rekening
from find_rekening import replace as replace_rekening
from tools import FOLDERS, MODE, OUTPUT_DIR, SOURCE_DIR, build_output_path, process_file

DETECTORS = [
    (detect_phone, replace_phone),
    (detect_email, replace_email),
    (detect_rekening, replace_rekening),
]

SCAN_DETECTORS = [
    ("Phone", detect_phone),
    ("Email", detect_email),
    ("Rekening", detect_rekening),
]

# Daftar detector: (detect_fn, replace_fn)
DETECTORS = [
    (detect_phone, replace_phone),
    (detect_email, replace_email),
]


def test_satu_file():
    path = os.path.join(
        SOURCE_DIR,
        "Data Atma Luhur",
        "2b2d5a48-e9e7-4950-8e16-553fb58aa60f",
        "_chat.txt",
    )
    dst = build_output_path(path)

    print("  Test: Satu File")
    print(f"  Sumber : {path}")
    print(f"  Tujuan : {dst}")
    print(f"  Mode   : {MODE}")

    result = process_file(path, dst, DETECTORS, mode=MODE, dry_run=True)
    if result["status"] == "error":
        print(f"\n  {result['msg']}")
        return

    print(f"\n  Baris   : {result['total_baris']}")
    print(f"  Item    : {result['total_nomor']} (di {result['baris_bernomor']} baris)")
    print()

    with open(path, "r", encoding="utf-8") as f:
        for i, line in enumerate(f, 1):
            phones = detect_phone(line)
            emails = detect_email(line)
            rekenings = detect_rekening(line)
            if phones or emails or rekenings:
                parts = []
                if phones:
                    parts.append(f"phone={','.join(phones)}")
                if emails:
                    parts.append(f"email={','.join(emails)}")
                if rekenings:
                    parts.append(f"rekening={','.join(rekenings)}")
                print(f"  baris {i}: {'; '.join(parts)}")
    print()


def scan_all():
    total_file = total_baris = 0
    totals = {label: 0 for label, _ in SCAN_DETECTORS}
    labels = [label for label, _ in SCAN_DETECTORS]

    header = f"{'Folder':<35} {'File':>6} {'Baris':>7}"
    for lbl in labels:
        header += f" {lbl:>9}"
    header += f" {'Total':>7}"
    print("  Scan All .txt")
    print(header)

    for folder in FOLDERS:
        fpath = os.path.join(SOURCE_DIR, folder)
        if not os.path.isdir(fpath):
            continue

        fc = bc = 0
        counts = {label: 0 for label, _ in SCAN_DETECTORS}

        for root, _, files in os.walk(fpath):
            for f in files:
                if not f.lower().endswith(".txt"):
                    continue
                fc += 1
                filepath = os.path.join(root, f)
                with open(filepath, "r", encoding="utf-8") as fh:
                    for line in fh:
                        found = False
                        for label, detect_fn in SCAN_DETECTORS:
                            items = detect_fn(line)
                            if items:
                                found = True
                                counts[label] += len(items)
                        if found:
                            bc += 1

        tot = sum(counts.values())
        row = f"  {folder:<35} {fc:>6} {bc:>7}"
        for lbl in labels:
            row += f" {counts[lbl]:>9}"
        row += f" {tot:>7}"
        print(row)

        total_file += fc
        total_baris += bc
        for lbl in labels:
            totals[lbl] += counts[lbl]

    total_all = sum(totals.values())
    row = f"  {'TOTAL':<35} {total_file:>6} {total_baris:>7}"
    for lbl in labels:
        row += f" {totals[lbl]:>9}"
    row += f" {total_all:>7}"
    print(row)
    print()


def run_all():
    if os.path.isdir(OUTPUT_DIR):
        shutil.rmtree(OUTPUT_DIR)

    total_f = 0
    total_p = total_e = total_r = 0

    print("Proses semua file ke folder result/ ...\n")

    for folder in FOLDERS:
        fpath = os.path.join(SOURCE_DIR, folder)
        if not os.path.isdir(fpath):
            continue

        fc = pc = ec = rc = 0
        for root, _, files in os.walk(fpath):
            for fname in files:
                if not fname.lower().endswith(".txt"):
                    continue
                fc += 1
                src = os.path.join(root, fname)
                dst = build_output_path(src)
                process_file(src, dst, DETECTORS, mode=MODE, dry_run=False)

                # Hitung rincian — scan langsung dari source
                with open(src, "r", encoding="utf-8") as fh:
                    for line in fh:
                        p = detect_phone(line)
                        e = detect_email(line)
                        r = detect_rekening(line)
                        if p:
                            pc += len(p)
                        if e:
                            ec += len(e)
                        if r:
                            rc += len(r)

        print(f"  {folder:<35} {fc:>4} file  phone={pc}  email={ec}  rekening={rc}")
        total_f += fc
        total_p += pc
        total_e += ec
        total_r += rc

    total_all = total_p + total_e + total_r
    print()
    print("  Selesai!")
    print(f"  File diproses : {total_f}")
    print(f"  Phone     : {total_p}")
    print(f"  Email     : {total_e}")
    print(f"  Rekening  : {total_r}")
    print(f"  Total     : {total_all}")
    print(f"  Output    : {OUTPUT_DIR}/")


def apply_satu_file():
    path = os.path.join(
        SOURCE_DIR,
        "Data Atma Luhur",
        "2b2d5a48-e9e7-4950-8e16-553fb58aa60f",
        "_chat.txt",
    )
    r = process_file(path, path, DETECTORS, mode=MODE, dry_run=False)
    print(f"File dibersihkan: {r['total_nomor']} item di {r['baris_bernomor']} baris")


def apply_all(confirm: bool = False):
    if not confirm:
        print("Peringatan: Ini akan mengubah SEMUA file .txt asli!")
        print("  Jalankan dulu: python3 clean_pii.py scan")
        print("  lalu jika yakin: python3 clean_pii.py apply-all --yes")
        return

    total_files = 0
    total_item = 0

    print("Membersihkan semua file .txt (in-place)...\n")

    for folder in FOLDERS:
        fpath = os.path.join(SOURCE_DIR, folder)
        if not os.path.isdir(fpath):
            continue

        fc = nc = 0
        for root, _, files in os.walk(fpath):
            for f in files:
                if not f.lower().endswith(".txt"):
                    continue
                src = os.path.join(root, f)
                r = process_file(src, src, DETECTORS, mode=MODE, dry_run=False)
                if r["total_nomor"] > 0:
                    fc += 1
                    nc += r["total_nomor"]
                    print(f"  {f:<50} {r['total_nomor']} item")

        if fc > 0:
            print(f"\n  {folder}: {fc} file dibersihkan ({nc} item)\n")
        total_files += fc
        total_item += nc

    print("=" * 60)
    print(f"  Selesai: {total_files} file, {total_item} item dihapus")


def print_usage():
    print("""
  Penggunaan:
    python3 clean_pii.py                    -> Preview 1 file test
    python3 clean_pii.py scan               -> Scan semua file
    python3 clean_pii.py run                -> Proses semua -> folder result/
    python3 clean_pii.py apply              -> Bersihkan 1 file (in-place)
    python3 clean_pii.py apply-all --yes    -> Bersihkan semua file (in-place)
    """)


if __name__ == "__main__":
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd == "scan":
            scan_all()
        elif cmd == "run":
            run_all()
        elif cmd == "test":
            test_satu_file()
        elif cmd == "apply":
            apply_satu_file()
        elif cmd == "apply-all":
            apply_all(confirm="--yes" in sys.argv)
        else:
            print_usage()
    else:
        test_satu_file()
